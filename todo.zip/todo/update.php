<?php
include 'db.php';
$id = $_GET['id'];
$title = $_POST['title'];
$status = $_POST['status'];
$conn->query("UPDATE tasks SET title='$title', status='$status' WHERE id=$id");
header("Location: index.php");
?>
