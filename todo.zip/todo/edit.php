<?php
include 'db.php';
$id = $_GET['id'];
$result = $conn->query("SELECT * FROM tasks WHERE id=$id");
$row = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Task</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5">
    <h2 class="mb-4">✏️ Edit Task</h2>
    <form action="update.php?id=<?= $id ?>" method="POST" class="d-flex gap-2 mb-4">
        <input type="text" name="title" value="<?= $row['title'] ?>" class="form-control" required>
        <select name="status" class="form-select">
            <option value="pending" <?= $row['status'] == 'pending' ? 'selected' : '' ?>>Pending</option>
            <option value="done" <?= $row['status'] == 'done' ? 'selected' : '' ?>>Done</option>
        </select>
        <button type="submit" class="btn btn-success">Update</button>
    </form>
    <a href="index.php" class="btn btn-secondary">Back</a>
</div>
</body>
</html>
