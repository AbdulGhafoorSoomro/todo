<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>To-Do List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5">
    <h2 class="mb-4">📝 My To-Do List</h2>
    <form action="insert.php" method="POST" class="mb-4 d-flex gap-2">
        <input type="text" name="title" class="form-control" placeholder="Enter task" required>
        <button type="submit" class="btn btn-primary">Add Task</button>
    </form>

    <ul class="list-group">
        <?php
        $result = $conn->query("SELECT * FROM tasks");
        while ($row = $result->fetch_assoc()) {
            echo "<li class='list-group-item d-flex justify-content-between align-items-center'>
                    <div>
                      <strong>{$row['title']}</strong> 
                      <span class='badge bg-secondary'>{$row['status']}</span>
                    </div>
                    <div>
                      <a href='edit.php?id={$row['id']}' class='btn btn-sm btn-warning'>Edit</a>
                      <a href='delete.php?id={$row['id']}' class='btn btn-sm btn-danger'>Delete</a>
                    </div>
                  </li>";
        }
        ?>
    </ul>
</div>
</body>
</html>
